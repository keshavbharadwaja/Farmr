import Person.Farmer;
import Person.WholeSaler;
public class Main {
    
    public static void main(String[] args)  {

        WholeSaler wholeSaler1 = new WholeSaler("Raju",(long) 1222233344);

        Farmer farmer1 = new Farmer("Sham", (long) 810585441);
        Farmer farmer2 = new Farmer("Babu", (long) 1234511122);
        Farmer farmer3 = new Farmer("Pappu", (long) 156234566);
        Farmer farmer4 = new Farmer("Peter", (long) 12344789);
        Farmer farmer5 = new Farmer("Gundu", (long) 967548476);
        Farmer farmer6 = new Farmer("Bala", (long) 987000006);
        try {
            wholeSaler1.addFarmer(farmer1);
            wholeSaler1.addFarmer(farmer2);
            wholeSaler1.addFarmer(farmer3);
            wholeSaler1.addFarmer(farmer4);
            wholeSaler1.addFarmer(farmer5);
            wholeSaler1.addFarmer(farmer6);

        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("Cannot add more than 5 farmers:");
        }

        System.out.println("Farmers");
        System.out.println("----------------------------------------------------------------------------------------------------------------");
        for (Farmer f : wholeSaler1.farmers) {
            System.out.printf("\n Name: %s and Phone: %s", f.getName(), f.getContact());
        }

    }

}
