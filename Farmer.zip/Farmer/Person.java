package Person;

import Exceptions.FarmerListExceeded;

interface Person {
   
    void addFarmer(Farmer f) throws FarmerListExceeded;

    void addWholesaler();
}