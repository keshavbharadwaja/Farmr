package Exceptions;
public class FarmerListExceeded extends Exception {

    public FarmerListExceeded() {
        super();

    }

    public FarmerListExceeded(String message) {

        System.out.println(message);

    }
}
