package Person;

import java.util.LinkedList;
import java.util.List;

import Exceptions.FarmerListExceededn;

public class WholeSaler extends FarmerListExceeded implements Person {
    String name;
    long Phone;

    public List<Farmer> farmers = new LinkedList<Farmer>();

    public WholeSaler(String string, Long i) {
        this.name = string;
        this.Phone = i;
    }

    public void addFarmer(Farmer f) throws FarmerListExceeded {
        // super.addFarmer();

        if (farmers.size() > 4) {
            throw new FarmerListExceeded();

        } else
            farmers.add(f);
            System.out.println("Farmer "+f.getName()+" added.");

    }

    @Override
    public void addWholesaler() {
       
    }

}
